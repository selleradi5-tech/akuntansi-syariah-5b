# Akuntansi Syariah 5B — Android

Android Studio project for the Akuntansi Syariah 5B class portal.

- Package: `com.akuntansisyariah.aks5b`
- Target/compile SDK: Android 16 / API 36
- Version: 1.0.0
- Portal URL: https://akuntansi-syariah-5b.hatchable.site/

## Build
Open this folder in Android Studio with a JDK supported by the selected Android Gradle Plugin, then:
1. Sync Gradle.
2. Build > Generate Signed Bundle / APK.
3. Choose Android App Bundle (AAB).
4. Sign the release with your upload key.
5. Upload the `.aab` to Google Play Console.

Important:
This is a WebView shell around the live portal. Before public Play Store release, the portal's current client-side login should be replaced with secure server/platform authentication.
